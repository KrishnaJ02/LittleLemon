from django.contrib import admin
from .models import Booking, Menu,Reservation

# Register your models here.
admin.site.register(Booking)
admin.site.register(Menu)
admin.site.register(Reservation)